package com.example.docs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    EditText emailLog, passLog;
    Button LoginDatos, RegisLog;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailLog = findViewById(R.id.emailLog);
        passLog = findViewById(R.id.passLog);
        LoginDatos = findViewById(R.id.LogDatos);
        RegisLog = findViewById(R.id.RegisLog);

        mAuth = FirebaseAuth.getInstance();

        LoginDatos.setOnClickListener(view -> {
            loginUser();
        });
        RegisLog.setOnClickListener(view -> {
            startActivity(new Intent(Login.this, SingUp.class));
        });
    }

    private void loginUser(){
        String email = emailLog.getText().toString();
        String pass = passLog.getText().toString();

        if(TextUtils.isEmpty(email)){
            emailLog.setError("Email canont be empty");
            emailLog.requestFocus();
        }else if (TextUtils.isEmpty(pass)){
            passLog.setError("Password canont be empty");
            passLog.requestFocus();
        }else {
            mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(Login.this,"User registered successfull", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(Login.this, MainActivity.class));

                    }else{
                        Toast.makeText(Login.this,"Login Error" + task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }


}