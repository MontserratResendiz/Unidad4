package com.example.docs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.concurrent.Executor;

public class Contrasenas extends AppCompatActivity {

    RecyclerView passList;
    DatabaseReference database;
    MyAdapter myAdapter;
    ArrayList<User> list;

    //----------------------------//

    BiometricPrompt biometricPrompt;
    BiometricPrompt.PromptInfo promptInfo;
    ConstraintLayout mLayout;
    private EditText contra1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrasenas);

        contra1 = findViewById(R.id.contra1);

        String archivosc[] = fileList();

        if(ArchivoContra(archivosc, "Contra.txt")){
            try{
                InputStreamReader archivoc = new InputStreamReader(openFileInput("Contra.txt"));
                BufferedReader br = new BufferedReader(archivoc);
                String linea = br.readLine();
                String contUser = "";

                while (linea != null){
                    contUser = contUser + linea + "\n";
                    linea = br.readLine();
                }
                br.close();
                archivoc.close();
                contra1.setText(contUser);

            }catch (IOException e){

            }
        }


    //----------------------------------------------------------//



    //----------------------------------------------------------//
        mLayout = findViewById(R.id.ContLayout);

        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate())
        {
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(getApplicationContext(),"Device Dosent have fingerprint",Toast.LENGTH_SHORT).show();
                break;

            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(getApplicationContext(),"Not Working",Toast.LENGTH_SHORT).show();

            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Toast.makeText(getApplicationContext(),"No FingerPrint assigned",Toast.LENGTH_SHORT).show();
        }

        Executor executor = ContextCompat.getMainExecutor(this);

        biometricPrompt = new BiometricPrompt(Contrasenas.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
            }

            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(getApplicationContext(),"Login sucess",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder().setTitle("Tech Projects")
                .setDescription("Use FingerPrint to Login").setDeviceCredentialAllowed(true).build();

        biometricPrompt.authenticate(promptInfo);

    }

    //---------------- METODOS PARA LAS COTRASEÑAS ---------------------------//

    private boolean ArchivoContra(String archivosc [], String NombreArchivo){
        for(int i = 0; i < archivosc.length; i++)
            if(NombreArchivo.equals(archivosc[i]))
                return true;
        return false;
    }

    public void GuardarContra(View view){

        try{
            OutputStreamWriter archivoc = new OutputStreamWriter(openFileOutput("Contra.txt", Activity.MODE_PRIVATE));
            archivoc.write(contra1.getText().toString());
            archivoc.flush();
            archivoc.close();
        }catch (IOException e){

        }

        Toast.makeText(this,"Nota guardada con exito",Toast.LENGTH_SHORT).show();

    }

}